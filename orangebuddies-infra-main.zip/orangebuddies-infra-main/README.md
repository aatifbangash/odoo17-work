# orangebuddies-infra

## what is it

This is infrastructure repository described using [HCL
2.0](https://github.com/hashicorp/hcl), [Atlantis](https://www.runatlantis.io)
as a actuator and [Terraform](https://terraform.io/) as a runner.

## Dependencies
| Project       | Dependencies      | Using Atlantis |
| ------------- | ----------------- | -------------- |
| VPC           | -                 | No             |
| KMS           | -                 | Yes            |
| Secrets       | KMS               | No             |
| ECS           | VPC, KMS, Secrets | Yes            |
| ApiGateway    | VPC, ECS          | Yes            |

## Useful commands

### Format terraform 
Required to pass validation step in atlantis workflow.
```hcl
terraform fmt -recursive -write=true
```

### Create specific project
```hcl
atlantis plan -p <PROJECT_NAME>
atlantis apply
```

### Destroy specific project
```hcl
atlantis plan -p <PROJECT_NAME> -- -destroy
atlantis apply
```

### Unlock plan specific project
Required to pass validation step in atlantis workflow.
```hcl
terraform fmt -recursive -write=true
```

By removing specific project argument ```-p <PROJECT_NAME>``` commands above will be applied on all projects affected in given pull request.


### Decode encoded authorization failures from AWS
Some AWS resources will return encoded error messages with must be decoded to read to exception.
```hcl
aws sts decode-authorization-message --encoded-message <ENCODED_MESSAGE>
```

### Applying manual changes
#### VPC
Hard dependency for now. Will be changed and described when we are not dependend on other cloud providers.


#### Secrets
See [Managing AWS Secrets](https://orangebuddies.atlassian.net/wiki/spaces/API/pages/162168833/Managing+AWS+Secrets)